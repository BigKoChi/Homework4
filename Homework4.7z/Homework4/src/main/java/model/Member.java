package model;

public class Member {

	private int id;
	private String memberNo;
	private String password;
	private String name;
	private String sex;
	private String department;
	private String jobTitle;
	
	
	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Member(String memberNo, String password, String name, String sex, String department, String jobTitle) {
		super();
		this.memberNo = memberNo;
		this.password = password;
		this.name = name;
		this.sex = sex;
		this.department = department;
		this.jobTitle = jobTitle;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getMemberNo() {
		return memberNo;
	}


	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getSex() {
		return sex;
	}


	public void setSex(String sex) {
		this.sex = sex;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public String getJobTitle() {
		return jobTitle;
	}


	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	
	
	
	
}
