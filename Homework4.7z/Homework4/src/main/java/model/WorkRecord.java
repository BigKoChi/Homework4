package model;

import java.sql.Date;
import java.sql.Time;

public class WorkRecord {

	private int id;
	private String department;
	private String memberNo;
	private String name;
	private String type;
	private Date date;
	private Time time;
	
	public WorkRecord() {
		super();
		// TODO Auto-generated constructor stub
	}

	public WorkRecord(String department, String memberNo, String name, String type, Date date, Time time) {
		super();
		this.department = department;
		this.memberNo = memberNo;
		this.name = name;
		this.type = type;
		this.date = date;
		this.time = time;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}

	
	
}