package dao;

import java.util.List;

import model.Member;

public interface MemberDao {
	
	void add(Member member); 
	List<Member> selectAll();
	Member selectByMemberNo(String memberNo);
	Member selectById(int id);
	int count(String yymm);
	void update(int id,Member member);
	void delete(int id);

}
