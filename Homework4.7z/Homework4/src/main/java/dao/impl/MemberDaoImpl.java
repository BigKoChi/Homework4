package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.MemberDao;
import model.Member;
import util.DbConnection;

public class MemberDaoImpl implements MemberDao{

	Connection conn=DbConnection.getDb();
	@Override
	public void add(Member member) {
		String sql="insert into member(memberNo,password,name,sex,department,jobTitle) values(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, member.getMemberNo());
			ps.setString(2, member.getPassword());
			ps.setString(3, member.getName());
			ps.setString(4, member.getSex());
			ps.setString(5, member.getDepartment());
			ps.setString(6, member.getJobTitle());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Member> selectAll() {
		String sql="select * from member";
		List<Member> listMember=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				Member member=new Member();
				member.setId(rs.getInt("id"));
				member.setMemberNo(rs.getString("memberNo"));
				member.setPassword(rs.getString("password"));
				member.setName(rs.getString("name"));
				member.setSex(rs.getString("sex"));
				member.setDepartment(rs.getString("department"));
				member.setJobTitle(rs.getString("jobTitle"));
				listMember.add(member);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listMember;
	}

	@Override
	public Member selectByMemberNo(String memberNo) {
		String sql="select * from member where memberNo=?";
		Member member=null;
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,memberNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				member=new Member();
				member.setId(rs.getInt("id"));
				member.setMemberNo(rs.getString("memberNo"));
				member.setPassword(rs.getString("password"));
				member.setName(rs.getString("name"));
				member.setSex(rs.getString("sex"));
				member.setDepartment(rs.getString("department"));
				member.setJobTitle(rs.getString("jobTitle"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return member;
	}

	@Override
	public Member selectById(int id) {
		String sql="select * from member where id=?";
		Member member=null;
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				member=new Member();
				member.setId(rs.getInt("id"));
				member.setMemberNo(rs.getString("memberNo"));
				member.setPassword(rs.getString("password"));
				member.setName(rs.getString("name"));
				member.setSex(rs.getString("sex"));
				member.setDepartment(rs.getString("department"));
				member.setJobTitle(rs.getString("jobTitle"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return member;
	}
	
	@Override
	public void update(int id,Member member) {
		String sql="update member set password=?,name=?,sex=?,department=?,jobTitle=? where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, member.getPassword());
			ps.setString(2, member.getName());
			ps.setString(3, member.getSex());
			ps.setString(4, member.getDepartment());
			ps.setString(5, member.getJobTitle());
			ps.setInt(6, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(int id) {
		String sql="select * from member where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	@Override
	public int count(String yymm) {
		int countInt=0;
		String sql="select count(*) as total FROM member where memberNo like ?";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			String ayymm="A"+yymm+"%";
			ps.setString(1, ayymm);
			ResultSet rs=ps.executeQuery();
			rs.next();
			countInt=rs.getInt("total");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return countInt;
	}

	

}
