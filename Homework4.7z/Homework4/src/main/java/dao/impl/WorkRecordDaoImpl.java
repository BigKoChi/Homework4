package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.WorkRecordDao;
import model.WorkRecord;
import util.DbConnection;

public class WorkRecordDaoImpl implements WorkRecordDao{

	Connection conn=DbConnection.getDb();
	@Override
	public void add(WorkRecord workRecord) {
		String sql="insert into workrecord(department,memberNo,name,type,date,time) values(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, workRecord.getDepartment());
			ps.setString(2, workRecord.getMemberNo());
			ps.setString(3, workRecord.getName());
			ps.setString(4, workRecord.getType());
			ps.setDate(5, workRecord.getDate());
			ps.setTime(6, workRecord.getTime());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<WorkRecord> selectAll() {
		String sql="select * from workrecord";
		List<WorkRecord> listworkRecord=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				WorkRecord workRecord=new WorkRecord();
				workRecord.setId(rs.getInt("id"));
				workRecord.setDepartment(rs.getString("department"));
				workRecord.setMemberNo(rs.getString("memberNo"));
				workRecord.setName(rs.getString("name"));
				workRecord.setType(rs.getString("type"));
				workRecord.setDate(rs.getDate("date"));
				workRecord.setTime(rs.getTime("time"));
				
				listworkRecord.add(workRecord);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listworkRecord;
	}

	@Override
	public WorkRecord selectById(int id) {
		String sql="select * from workrecord where id=?";
		WorkRecord workRecord=null;
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				workRecord=new WorkRecord();
				
				workRecord.setId(rs.getInt("id"));
				workRecord.setDepartment(rs.getString("department"));
				workRecord.setMemberNo(rs.getString("memberNo"));
				workRecord.setName(rs.getString("name"));
				workRecord.setType(rs.getString("type"));
				workRecord.setDate(rs.getDate("date"));
				workRecord.setTime(rs.getTime("time"));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return workRecord;
	}
	
	@Override
	public List<WorkRecord> selectByMemberNo(String memberNo) {
		String sql="select * from workrecord where memberNo=?";
		List<WorkRecord> listworkRecord=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, memberNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				WorkRecord workRecord=new WorkRecord();
				workRecord.setId(rs.getInt("id"));
				workRecord.setDepartment(rs.getString("department"));
				workRecord.setMemberNo(rs.getString("memberNo"));
				workRecord.setName(rs.getString("name"));
				workRecord.setType(rs.getString("type"));
				workRecord.setDate(rs.getDate("date"));
				workRecord.setTime(rs.getTime("time"));

				listworkRecord.add(workRecord);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listworkRecord;
	}

	@Override
	public void update(int id,WorkRecord workRecord) {
		String sql="update workrecord set type=?,date=?,time=? where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, workRecord.getType());
			ps.setDate(2, workRecord.getDate());
			ps.setTime(3, workRecord.getTime());
			ps.setInt(4, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void delete(int id) {
		String sql="delete from workrecord where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
