package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.LeaveRecordDao;
import model.LeaveRecord;
import util.DbConnection;

public class LeaveRecordDaoImpl implements LeaveRecordDao{

	Connection conn=DbConnection.getDb();
	@Override
	public void add(LeaveRecord leaveRecord) {
		String sql="insert into leaverecord(department,memberNo,name,type,dateStart,timeStart,dateEnd,timeEnd) values(?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, leaveRecord.getDepartment());
			ps.setString(2, leaveRecord.getMemberNo());
			ps.setString(3, leaveRecord.getName());
			ps.setString(4, leaveRecord.getType());
			ps.setDate(5, leaveRecord.getDateStart());
			ps.setTime(6, leaveRecord.getTimeStart());
			ps.setDate(7, leaveRecord.getDateEnd());
			ps.setTime(8, leaveRecord.getTimeEnd());

			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<LeaveRecord> selectAll() {
		String sql="select * from leaverecord";
		List<LeaveRecord> listleaveRecord=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				LeaveRecord leaveRecord=new LeaveRecord();
				leaveRecord.setId(rs.getInt("id"));
				leaveRecord.setDepartment(rs.getString("department"));
				leaveRecord.setMemberNo(rs.getString("memberNo"));
				leaveRecord.setName(rs.getString("name"));
				leaveRecord.setType(rs.getString("type"));
				leaveRecord.setDateStart(rs.getDate("dateStart"));
				leaveRecord.setTimeStart(rs.getTime("timeStart"));
				leaveRecord.setDateEnd(rs.getDate("dateEnd"));
				leaveRecord.setTimeEnd(rs.getTime("timeEnd"));
				listleaveRecord.add(leaveRecord);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listleaveRecord;
	}

	@Override
	public LeaveRecord selectById(int id) {
		String sql="select * from leaverecord where id=?";
		LeaveRecord leaveRecord=null;
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				leaveRecord=new LeaveRecord();
				leaveRecord.setId(rs.getInt("id"));
				leaveRecord.setDepartment(rs.getString("department"));
				leaveRecord.setMemberNo(rs.getString("memberNo"));
				leaveRecord.setName(rs.getString("name"));
				leaveRecord.setType(rs.getString("type"));
				leaveRecord.setDateStart(rs.getDate("dateStart"));
				leaveRecord.setTimeStart(rs.getTime("timeStart"));
				leaveRecord.setDateEnd(rs.getDate("dateEnd"));
				leaveRecord.setTimeEnd(rs.getTime("timeEnd"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return leaveRecord;
	}
	@Override
	public List<LeaveRecord> selectByMemberNo(String memberNo) {
		String sql="select * from leaverecord where memberNo=?";
		List<LeaveRecord> listleaveRecord=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, memberNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				LeaveRecord leaveRecord=new LeaveRecord();
				leaveRecord.setId(rs.getInt("id"));
				leaveRecord.setDepartment(rs.getString("department"));
				leaveRecord.setMemberNo(rs.getString("memberNo"));
				leaveRecord.setName(rs.getString("name"));
				leaveRecord.setType(rs.getString("type"));
				leaveRecord.setDateStart(rs.getDate("dateStart"));
				leaveRecord.setTimeStart(rs.getTime("timeStart"));
				leaveRecord.setDateEnd(rs.getDate("dateEnd"));
				leaveRecord.setTimeEnd(rs.getTime("timeEnd"));
				listleaveRecord.add(leaveRecord);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listleaveRecord;
	}

	@Override
	public void update(int id,LeaveRecord leaveRecord) {
		String sql="update leaverecord set type=?,dateStart=?,timeStart=?,dateEnd=?,timeEnd=? where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, leaveRecord.getType());
			ps.setDate(2, leaveRecord.getDateStart());
			ps.setTime(3, leaveRecord.getTimeStart());
			ps.setDate(4, leaveRecord.getDateEnd());
			ps.setTime(5, leaveRecord.getTimeEnd());
			
			ps.setInt(6, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(int id) {
		String sql="delete from leaverecord where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	
}
