package dao;

import java.util.List;

import model.LeaveRecord;


public interface LeaveRecordDao {

	void add(LeaveRecord leaveRecord); 
	List<LeaveRecord> selectAll();
	LeaveRecord selectById(int id);
	List<LeaveRecord> selectByMemberNo(String memberNo);
	void update(int id,LeaveRecord leaveRecord);
	void delete(int id);
}
