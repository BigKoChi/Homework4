package dao;

import java.util.List;

import model.WorkRecord;

public interface WorkRecordDao {

	void add(WorkRecord workRecord); 
	List<WorkRecord> selectAll();
	WorkRecord selectById(int id);
	List<WorkRecord> selectByMemberNo(String memberNo);
	void update(int id,WorkRecord workRecord);
	void delete(int id);
}
