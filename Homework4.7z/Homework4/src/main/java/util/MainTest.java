package util;

import java.sql.Connection;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import dao.impl.LeaveRecordDaoImpl;
import dao.impl.MemberDaoImpl;
import dao.impl.WorkRecordDaoImpl;
import model.LeaveRecord;
import model.Member;
import model.WorkRecord;
import service.impl.LeaveRecordServiceImpl;
import service.impl.MemberServiceImpl;
import service.impl.WorkRecordServiceImpl;

public class MainTest {

	public static void main(String[] args) {
		/* 資料庫連接測試 */
//		 	Connection conn=DbConnection.getDb();
		
/* MemberDaoImpl測試*/
		 MemberDaoImpl mdl=new MemberDaoImpl();
//		 Member m=new Member("202508003","789","小李","Male","工程部","員工");
//		 mdl.add(m);
//		 mdl.update(m);
//		 mdl.delete("202508002");
		 
//		 Member m=mdl.selectByMemberNo("202508005");
//		 System.out.println(m);
//		 System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getPassword()+" "+m.getName()+" "+m.getSex()+" "+m.getDepartment()+" "+m.getJobTitle());
		 
//		 List<Member> lm=mdl.selectAll();
//		 for(Member m:lm) 
//		 {
//			 System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getPassword()+" "+m.getName()+" "+m.getSex()+" "+m.getDepartment()+" "+m.getJobTitle());
//		 }
		 
		 System.out.println(mdl.count("2508"));
		 
/* MemberServiceImpl測試*/
		 MemberServiceImpl msi=new MemberServiceImpl();
//		 Member m=new Member("202508003","456","小芳","Female","會計部","主管");
//		 System.out.println(msi.addMember(m));
//		 System.out.println(msi.updateMember(m));
//		 System.out.println(msi.deleteMember(m.getMemberNo()));
//		 Member m=msi.findByMemberNo("202508002");
//		 System.out.println(m);
//		 List<Member> lm=msi.findAllMember();
//		 for(Member m:lm) 
//		 {
//			 System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getPassword()+" "+m.getName()+" "+m.getSex()+" "+m.getDepartment()+" "+m.getJobTitle());
// 
//		 }
		 
		 System.out.println(msi.countMemberNo("2507"));
		 
/* WorkRecordDaoImpl測試*/
//		WorkRecordDaoImpl wdi=new WorkRecordDaoImpl();
//		 Date d=new Date(System.currentTimeMillis());
//		 Time t=new Time(System.currentTimeMillis());
//		 Date d=Date.valueOf("2025-7-15");
//		 Time t=Time.valueOf("09:00:10");
//		 WorkRecord wr=new WorkRecord("202508001","下班",d,t);
//		 wdi.add(wr);
//		 wdi.update(1, wr);
//		 wdi.delete(3);
//		 List<WorkRecord> lm=wdi.selectByMemberNo("202508002");
//		 List<WorkRecord> lm=wdi.selectAll();
//		 WorkRecord m=wdi.selectById(6);
//		 System.out.println(lm);
//		 for(WorkRecord m:lm) 
//		 {			 
//			 System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getType()+" "+m.getDate()+" "+m.getTime());
//		 }
//		 WorkRecord m=wdi.selectById(2);
//		 System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getType()+" "+m.getDate()+" "+m.getTime());

/* WorkRecordServiceImpl測試*/
//		WorkRecordServiceImpl wsi=new WorkRecordServiceImpl();
//		Date d=new Date(System.currentTimeMillis());
//		Time t=new Time(System.currentTimeMillis());
//		WorkRecord wr=new WorkRecord("202508003","下班",d,t);
//		wsi.addWorkRecord(wr);
//		System.out.println(wsi.updateWorkRecord(6, wr));
//		System.out.println(wsi.deleteWorkRecord(5));
//		List<WorkRecord> lw=wsi.findAllWorkRecord();
//		List<WorkRecord> lw=wsi.findByMemberNo("202508002");
//		for(WorkRecord w:lw) 
//		{
//			System.out.println(w.getId()+" "+w.getMemberNo()+" "+w.getType()+" "+w.getDate()+" "+w.getTime());
//		}
		
/* LeaveRecordDaoImpl測試*/
//		 LeaveRecordDaoImpl ldi=new LeaveRecordDaoImpl();
//		 Date d=Date.valueOf("2025-8-13");
//		 Time t=Time.valueOf("12:00:00");
//		 Date d1=Date.valueOf("2025-8-14");
//		 Time t1=Time.valueOf("14:00:00");
//		 LeaveRecord lr=new LeaveRecord("202508001","病假",d,t,d1,t1);
//		 ldi.add(lr);
//		 ldi.update(2, lr);
//		 ldi.delete(3);
//		 List<LeaveRecord> lm=ldi.selectByMemberNo("202508001");
//		 LeaveRecord m=ldi.selectById(3);
//		 List<LeaveRecord> lm=ldi.selectAll();
//		 System.out.println(lm);
//		 for(LeaveRecord m:lm) 
//		 {			 
//			 System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getType()+" "+m.getDateStart()+" "+m.getTimeStart()+" "+m.getDateEnd()+" "+m.getTimeEnd());
//		 }
		
/* LeaveRecordServiceImpl測試*/	
//		LeaveRecordServiceImpl lsi=new LeaveRecordServiceImpl();
//		 Date d=Date.valueOf("2025-8-21");
//		 Time t=Time.valueOf("12:00:00");
//		 Date d1=Date.valueOf("2025-8-21");
//		 Time t1=Time.valueOf("14:00:00");
//		 LeaveRecord lr=new LeaveRecord("202508001","特休",d,t,d1,t1);
//		lsi.addLeaveRecord(lr);
//		System.out.println(lsi.updateMember(7, lr));
//		System.out.println(lsi.deleteMember(6));
//		List<LeaveRecord> lw=lsi.findAllLeaveRecord();
//		List<LeaveRecord> lw=lsi.findByMemberNo("202508001");
//		for(LeaveRecord w:lw) 
//		{
//			System.out.println(w.getId()+" "+w.getMemberNo()+" "+w.getType()+" "+w.getDateStart()+" "+w.getTimeStart()+" "+w.getDateEnd()+" "+w.getTimeEnd());
//		}
	}

}
