package util;

import java.util.List;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.LeaveRecord;
import model.Member;
import model.WorkRecord;
import service.impl.LeaveRecordServiceImpl;
import service.impl.MemberServiceImpl;
import service.impl.WorkRecordServiceImpl;

public class Tool {

	MemberServiceImpl msi=new MemberServiceImpl();
	WorkRecordServiceImpl wsi=new WorkRecordServiceImpl();
	LeaveRecordServiceImpl lsi=new LeaveRecordServiceImpl();
	
	public DefaultTableModel getTM_Member_All() 
	{
		String[] title= {"Id","員編","密碼","姓名","性別","部門","職位"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		List<Member> memberlist=msi.findAllMember();
		for(Member m:memberlist)
		{
			String[] memberDate=new String[7];
			memberDate[0]=""+m.getId();
			memberDate[1]=m.getMemberNo();
			memberDate[2]=m.getPassword();
			memberDate[3]=m.getName();
			memberDate[4]=m.getSex();
			memberDate[5]=m.getDepartment();
			memberDate[6]=m.getJobTitle();
			tableModel.addRow(memberDate);
		}
		
		return tableModel;
	}
	
	public DefaultTableModel getTM_Member_Dep(String dep) 
	{
		String[] title= {"Id","員編","密碼","姓名","性別","部門","職位"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		List<Member> memberlist=msi.findAllMember();
		for(Member m:memberlist)
		{
			if(m.getDepartment().equals(dep)) 
			{
				String[] memberDate=new String[7];
				memberDate[0]=""+m.getId();
				memberDate[1]=m.getMemberNo();
				memberDate[2]=m.getPassword();
				memberDate[3]=m.getName();
				memberDate[4]=m.getSex();
				memberDate[5]=m.getDepartment();
				memberDate[6]=m.getJobTitle();
				tableModel.addRow(memberDate);
			}
		}
		
		return tableModel;
	}
	
	public DefaultTableModel getTM_Member_mem(String mem) 
	{
		String[] title= {"Id","員編","密碼","姓名","性別","部門","職位"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		List<Member> memberlist=msi.findAllMember();
		for(Member m:memberlist)
		{
			if(m.getMemberNo().equals(mem)) 
			{
				String[] memberDate=new String[7];
				memberDate[0]=""+m.getId();
				memberDate[1]=m.getMemberNo();
				memberDate[2]=m.getPassword();
				memberDate[3]=m.getName();
				memberDate[4]=m.getSex();
				memberDate[5]=m.getDepartment();
				memberDate[6]=m.getJobTitle();
				tableModel.addRow(memberDate);
			}
		}
		
		return tableModel;
	}
	public DefaultTableModel getTM_WorkRecord_All() 
	{
		String[] title= {"Id","部門","員編","姓名","燈號","日期","時間"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		List<WorkRecord> workRecordlist=wsi.findAllWorkRecord();
		for(WorkRecord m:workRecordlist)
		{
			String[] sqlDate=new String[7];
			sqlDate[0]=""+m.getId();
			sqlDate[1]=""+m.getDepartment();
			sqlDate[2]=m.getMemberNo();
			sqlDate[3]=""+m.getName();
			sqlDate[4]=m.getType();
			sqlDate[5]=""+m.getDate();
			sqlDate[6]=""+m.getTime();
			
			tableModel.addRow(sqlDate);
		}
		return tableModel;
	}
	
	public DefaultTableModel getTM_WorkRecord_Dep(String dep) 
	{
		String[] title= {"Id","部門","員編","姓名","燈號","日期","時間"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		List<WorkRecord> workRecordlist=wsi.findAllWorkRecord();
		for(WorkRecord m:workRecordlist)
		{
			if(m.getDepartment().equals(dep)) 
			{
				String[] sqlDate=new String[7];
				sqlDate[0]=""+m.getId();
				sqlDate[1]=""+m.getDepartment();
				sqlDate[2]=m.getMemberNo();
				sqlDate[3]=""+m.getName();
				sqlDate[4]=m.getType();
				sqlDate[5]=""+m.getDate();
				sqlDate[6]=""+m.getTime();
				tableModel.addRow(sqlDate);
			}
		}
		return tableModel;
	}
	
	public DefaultTableModel getTM_WorkRecord_mem(String mem) 
	{
		String[] title= {"Id","部門","員編","姓名","燈號","日期","時間"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		List<WorkRecord> workRecordlist=wsi.findAllWorkRecord();
		for(WorkRecord m:workRecordlist)
		{
			if(m.getMemberNo().equals(mem)) 
			{
				String[] sqlDate=new String[7];
				sqlDate[0]=""+m.getId();
				sqlDate[1]=""+m.getDepartment();
				sqlDate[2]=m.getMemberNo();
				sqlDate[3]=""+m.getName();
				sqlDate[4]=m.getType();
				sqlDate[5]=""+m.getDate();
				sqlDate[6]=""+m.getTime();
			
				tableModel.addRow(sqlDate);
			}
		}
		return tableModel;
	}
	
	public DefaultTableModel getTM_LeaveRecord_All() 
	{
		String[] title= {"Id","部門","員編","姓名","種類","日期起","時間起","日期迄","時間迄"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		
		List<LeaveRecord> LeaveRecordlist=lsi.findAllLeaveRecord();
		for(LeaveRecord m:LeaveRecordlist)
		{
			String[] sqlDate=new String[9];
			sqlDate[0]=""+m.getId();
			sqlDate[1]=""+m.getDepartment();
			sqlDate[2]=m.getMemberNo();
			sqlDate[3]=""+m.getName();
			sqlDate[4]=m.getType();
			sqlDate[5]=""+m.getDateStart();
			sqlDate[6]=""+m.getTimeStart();
			sqlDate[7]=""+m.getDateEnd();
			sqlDate[8]=""+m.getTimeEnd();
			
			tableModel.addRow(sqlDate);
		}
		return tableModel;
	}
	
	public DefaultTableModel getTM_LeaveRecord_Dep(String dep) 
	{
		String[] title= {"Id","部門","員編","姓名","種類","日期起","時間起","日期迄","時間迄"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		
		List<LeaveRecord> LeaveRecordlist=lsi.findAllLeaveRecord();
		for(LeaveRecord m:LeaveRecordlist)
		{
			if(m.getDepartment().equals(dep)) 
			{
				String[] sqlDate=new String[9];
				sqlDate[0]=""+m.getId();
				sqlDate[1]=""+m.getDepartment();
				sqlDate[2]=m.getMemberNo();
				sqlDate[3]=""+m.getName();
				sqlDate[4]=m.getType();
				sqlDate[5]=""+m.getDateStart();
				sqlDate[6]=""+m.getTimeStart();
				sqlDate[7]=""+m.getDateEnd();
				sqlDate[8]=""+m.getTimeEnd();
			
				tableModel.addRow(sqlDate);
			}
		}
		return tableModel;
	}
	public DefaultTableModel getTM_LeaveRecord_mem(String mem) 
	{
		String[] title= {"Id","部門","員編","姓名","種類","日期起","時間起","日期迄","時間迄"};
		DefaultTableModel tableModel = new DefaultTableModel(title,0);
		
		List<LeaveRecord> LeaveRecordlist=lsi.findAllLeaveRecord();
		for(LeaveRecord m:LeaveRecordlist)
		{
			if(m.getMemberNo().equals(mem)) 
			{
				String[] sqlDate=new String[9];
				sqlDate[0]=""+m.getId();
				sqlDate[1]=""+m.getDepartment();
				sqlDate[2]=m.getMemberNo();
				sqlDate[3]=""+m.getName();
				sqlDate[4]=m.getType();
				sqlDate[5]=""+m.getDateStart();
				sqlDate[6]=""+m.getTimeStart();
				sqlDate[7]=""+m.getDateEnd();
				sqlDate[8]=""+m.getTimeEnd();
			
				tableModel.addRow(sqlDate);
			}
		}
		return tableModel;
	}
}
