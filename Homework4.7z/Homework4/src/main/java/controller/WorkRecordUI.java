package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.WorkRecord;
import service.impl.WorkRecordServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.Timer;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.sql.Time;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.ButtonGroup;

public class WorkRecordUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WorkRecordUI frame = new WorkRecordUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public WorkRecordUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 308, 201);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 268, 142);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JRadioButton Radio_1 = new JRadioButton("上班");
		Radio_1.setSelected(true);
		buttonGroup.add(Radio_1);
		Radio_1.setBounds(6, 36, 58, 23);
		panel.add(Radio_1);
		
		JRadioButton Radio_2 = new JRadioButton("下班");
		buttonGroup.add(Radio_2);
		Radio_2.setBounds(6, 77, 58, 23);
		panel.add(Radio_2);
		
		JRadioButton Radio_3 = new JRadioButton("加班上班");
		buttonGroup.add(Radio_3);
		Radio_3.setBounds(84, 36, 85, 23);
		panel.add(Radio_3);
		
		JRadioButton Radio_4 = new JRadioButton("加班下班");
		buttonGroup.add(Radio_4);
		Radio_4.setBounds(84, 77, 85, 23);
		panel.add(Radio_4);
		
		JLabel Label_name = new JLabel("");
		Label_name.setBounds(6, 10, 256, 23);
		panel.add(Label_name);
		
		Label_name.setText("使用者: "+LoginUI.member.getName());
		
		JLabel Label_nowTime = new JLabel("");
		Label_nowTime.setBounds(6, 106, 256, 23);
		panel.add(Label_nowTime);
		
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("YYYY/MM/dd HH:mm:ss");
		Timer timer=new Timer(1000,e->{
			LocalDateTime ldt=LocalDateTime.now();
			String nowTime=ldt.format(formatter);
			Label_nowTime.setText(nowTime);
		});
		timer.start();
		
		/********按鈕區*******/
		
		WorkRecordServiceImpl wsi=new WorkRecordServiceImpl();
		
		JButton btnNewButton = new JButton("打卡");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String type="";
				if(Radio_1.isSelected()) {type="上班";}
				else if(Radio_2.isSelected()) {type="下班";}
				else if(Radio_3.isSelected()) {type="加上班";}
				else if(Radio_4.isSelected()) {type="加下班";}
				Date date=new Date(System.currentTimeMillis());
				Time time=new Time(System.currentTimeMillis());
				WorkRecord workRecord=new WorkRecord(LoginUI.member.getDepartment(),LoginUI.member.getMemberNo(),LoginUI.member.getName(),type,date,time);
				wsi.addWorkRecord(workRecord);
				JOptionPane.showMessageDialog(btnNewButton, "打卡成功。");
			}
		});
		btnNewButton.setBounds(188, 36, 74, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("返回");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuUI menuUi=new MenuUI();
				menuUi.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(188, 77, 74, 23);
		panel.add(btnNewButton_1);
	}

}
