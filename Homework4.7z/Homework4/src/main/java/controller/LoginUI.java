package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Member;
import service.impl.MemberServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_memberNo;
	private JPasswordField passwordField;
	
	public static Member member;
	public static int updateId;
	public static boolean updateState=false;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI frame = new LoginUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 308, 280);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(20, 45, 247, 163);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("員編:");
		lblNewLabel_1.setBounds(41, 39, 46, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("密碼:");
		lblNewLabel_2.setBounds(41, 79, 46, 15);
		panel.add(lblNewLabel_2);
		
		textField_memberNo = new JTextField();
		textField_memberNo.setBounds(97, 36, 96, 21);
		panel.add(textField_memberNo);
		textField_memberNo.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(97, 76, 96, 21);
		panel.add(passwordField);
		
		JLabel lblNewLabel = new JLabel(" 有 間 公 司 人 資 系 統");
		lblNewLabel.setFont(new Font("新細明體", Font.BOLD, 18));
		lblNewLabel.setBounds(34, 10, 233, 25);
		contentPane.add(lblNewLabel);

		/*************按鈕區**************/
		MemberServiceImpl msi=new MemberServiceImpl();
		
		JButton Button_login = new JButton("登入");
		Button_login.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				member=msi.findByMemberNo(textField_memberNo.getText());
				if(member!=null) 
				{
					boolean passwordCheck=member.getPassword().equals(new String(passwordField.getPassword()));
					if(passwordCheck) 
					{
					MenuUI menuUI=new MenuUI();
					menuUI.setVisible(true);
					dispose();
					}
					else 
					{
						JOptionPane.showMessageDialog(Button_login, "密碼錯誤，請重新輸入。");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(Button_login, "查無此帳號，請先用主管帳號進入新增。");
				}
			
			}
		});
		Button_login.setBounds(73, 126, 87, 23);
		panel.add(Button_login);
	}
}
