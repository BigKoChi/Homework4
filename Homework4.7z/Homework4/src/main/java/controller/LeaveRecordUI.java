package controller;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.toedter.calendar.JDateChooser;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Date;
import java.sql.Time;
import java.text.SimpleDateFormat;

import model.LeaveRecord;
import service.impl.LeaveRecordServiceImpl;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;




public class LeaveRecordUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LeaveRecordUI frame = new LeaveRecordUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LeaveRecordUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 378, 272);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 343, 213);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(66, 53, 62, 23);
		panel.add(comboBox);
		
		comboBox.addItem("事假");
		comboBox.addItem("病假");
		comboBox.addItem("特休");
		
		JLabel Label_name = new JLabel("");
		Label_name.setBounds(10, 10, 96, 23);
		panel.add(Label_name);
		
		Label_name.setText("使用者: "+LoginUI.member.getName());
		
		JLabel lblNewLabel = new JLabel("假別:");
		lblNewLabel.setBounds(10, 57, 46, 15);
		panel.add(lblNewLabel);
		
	
		JLabel lblNewLabel_1 = new JLabel("日期起:");
		lblNewLabel_1.setBounds(10, 99, 46, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("日期迄:");
		lblNewLabel_2.setBounds(10, 130, 46, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("時間起:");
		lblNewLabel_3.setBounds(10, 174, 46, 15);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel(":");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("新細明體", Font.BOLD, 14));
		lblNewLabel_4.setBounds(90, 174, 19, 15);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel(":");
		lblNewLabel_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4_1.setFont(new Font("新細明體", Font.BOLD, 14));
		lblNewLabel_4_1.setBounds(263, 174, 19, 15);
		panel.add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("時間迄:");
		lblNewLabel_3_1.setBounds(183, 174, 46, 15);
		panel.add(lblNewLabel_3_1);
		
		JSpinner spinner_hourStart = new JSpinner();
		spinner_hourStart.setModel(new SpinnerNumberModel(0, 0, 23, 1));
		spinner_hourStart.setBounds(53, 171, 39, 22);
		panel.add(spinner_hourStart);
		
		JSpinner spinner_minStart = new JSpinner();
		spinner_minStart.setModel(new SpinnerNumberModel(0, 0, 59, 1));
		spinner_minStart.setBounds(110, 171, 39, 22);
		panel.add(spinner_minStart);
		
		JSpinner spinner_hourEnd = new JSpinner();
		spinner_hourEnd.setModel(new SpinnerNumberModel(0, 0, 23, 1));
		spinner_hourEnd.setBounds(225, 171, 39, 22);
		panel.add(spinner_hourEnd);
		
		JSpinner spinner_minEnd = new JSpinner();
		spinner_minEnd.setModel(new SpinnerNumberModel(0, 0, 59, 1));
		spinner_minEnd.setBounds(282, 171, 39, 22);
		panel.add(spinner_minEnd);
		
		JDateChooser dateChooser_1=new JDateChooser();
		dateChooser_1.setDateFormatString("y-M-d");
		dateChooser_1.setBounds(53,91,134,23);
		panel.add(dateChooser_1);
		dateChooser_1.setDate(null);
		JDateChooser dateChooser_2=new JDateChooser();
		dateChooser_2.setDateFormatString("y-M-d");
		dateChooser_2.setBounds(53,124,134,23);
		panel.add(dateChooser_2);
		
		/*********按鈕區********/
		LeaveRecordServiceImpl lsi=new LeaveRecordServiceImpl();
		
		JButton Button_add = new JButton("送出");
		Button_add.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String type=(String) comboBox.getSelectedItem();
				
			if(LoginUI.updateState) 
			{
				Date dateStart=new Date(dateChooser_1.getDate().getTime());
				Date dateEnd=new Date(dateChooser_2.getDate().getTime());
			
				Time timeStart=Time.valueOf(spinner_hourStart.getValue()+":"+spinner_minStart.getValue()+":00");
				Time timeEnd=Time.valueOf(spinner_hourEnd.getValue()+":"+spinner_minEnd.getValue()+":00");
			
				if(dateStart.after(dateEnd))
				{
					JOptionPane.showMessageDialog(Button_add, "起始日期不可大於結束日期");
				}
				else if((dateStart==dateEnd) && timeStart.after(timeEnd)) 
				{
					JOptionPane.showMessageDialog(Button_add, "起始時間不可大於結束時間");
				}
				else 
				{
					LeaveRecord lr=new LeaveRecord(LoginUI.member.getDepartment(),LoginUI.member.getMemberNo(),LoginUI.member.getName(),type,dateStart,timeStart,dateEnd,timeEnd);
					lsi.updateLeaveRecord(LoginUI.updateId, lr);
					JOptionPane.showMessageDialog(Button_add, "修改完成。");
					dateChooser_1.setDate(null);
					dateChooser_2.setDate(null);
					spinner_hourStart.setValue(0);;
					spinner_minStart.setValue(0);
					spinner_hourEnd.setValue(0);
					spinner_minEnd.setValue(0);
					LoginUI.updateState=false;
					dispose();
				}
			}
			else {
			
					Date dateStart=new Date(dateChooser_1.getDate().getTime());
					Date dateEnd=new Date(dateChooser_2.getDate().getTime());
				
					Time timeStart=Time.valueOf(spinner_hourStart.getValue()+":"+spinner_minStart.getValue()+":00");
					Time timeEnd=Time.valueOf(spinner_hourEnd.getValue()+":"+spinner_minEnd.getValue()+":00");
				
					if(dateStart.after(dateEnd))
					{
						JOptionPane.showMessageDialog(Button_add, "起始日期不可大於結束日期");
					}
					else if((dateStart==dateEnd) && timeStart.after(timeEnd)) 
					{
						JOptionPane.showMessageDialog(Button_add, "起始時間不可大於結束時間");
					}
					else 
					{
						LeaveRecord lr=new LeaveRecord(LoginUI.member.getDepartment(),LoginUI.member.getMemberNo(),LoginUI.member.getName(),type,dateStart,timeStart,dateEnd,timeEnd);
						lsi.addLeaveRecord(lr);
						JOptionPane.showMessageDialog(Button_add, "新增完成。");
						dateChooser_1.setDate(null);
						dateChooser_2.setDate(null);
						spinner_hourStart.setValue(0);;
						spinner_minStart.setValue(0);
						spinner_hourEnd.setValue(0);
						spinner_minEnd.setValue(0);
					}
			}
			}
		});
		Button_add.setBounds(167, 53, 71, 23);
		panel.add(Button_add);
		
		JButton Button_back = new JButton("返回");
		Button_back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuUI menuUi=new MenuUI();
				menuUi.setVisible(true);
				dispose();
			}
		});
		Button_back.setBounds(251, 53, 71, 23);
		panel.add(Button_back);
		
		
		
		
		
		
		

	}
}
