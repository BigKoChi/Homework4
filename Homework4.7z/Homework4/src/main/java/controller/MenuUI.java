package controller;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.border.EmptyBorder;



import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class MenuUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuUI frame = new MenuUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MenuUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 249, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 204, 241);
		contentPane.add(panel);
		panel.setLayout(null);
		
	
		
		JLabel Label_name = new JLabel("");
		Label_name.setBounds(10, 10, 184, 24);
		panel.add(Label_name);
		
		Label_name.setText(LoginUI.member.getName()+" 歡迎使用本系統");
		
		
		
		/*****************按鈕區******************/
		
		JButton Button_workRecord = new JButton("打卡");
		Button_workRecord.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				WorkRecordUI workRecordUi=new WorkRecordUI();
				workRecordUi.setVisible(true);
				dispose();
			}
		});
		Button_workRecord.setBounds(55, 44, 87, 23);
		panel.add(Button_workRecord);
		
		JButton Button_back = new JButton("切換帳號");
		Button_back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginUI loginUi=new LoginUI();
				loginUi.setVisible(true);
				dispose();
			}
		});
		Button_back.setBounds(55, 176, 87, 23);
		panel.add(Button_back);
		
		JButton Button_query = new JButton("資料查詢");
		Button_query.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				QueryUI queryUi=new QueryUI();
				queryUi.setVisible(true);
				dispose();
			}
		});
		Button_query.setBounds(55, 110, 87, 23);
		panel.add(Button_query);
		
		JButton Button_leaveRecord = new JButton("請假");
		Button_leaveRecord.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LeaveRecordUI leaveRecordUi=new LeaveRecordUI();
				leaveRecordUi.setVisible(true);
				dispose();
			}
		});
		Button_leaveRecord.setBounds(55, 77, 87, 23);
		panel.add(Button_leaveRecord);
		
		JButton Button_addMember = new JButton("新增人員");
		Button_addMember.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(LoginUI.member.getJobTitle().equals("職員")) {
					JOptionPane.showMessageDialog(Button_addMember, "職員等級無此權限");
				}
				else 
				{
					MemberUI memberUi=new MemberUI();
					memberUi.setVisible(true);
					dispose();
				}
			}
		});
		Button_addMember.setBounds(55, 143, 87, 23);
		panel.add(Button_addMember);
		
		JButton btnNewButton = new JButton("離開");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		btnNewButton.setBounds(55, 209, 87, 23);
		panel.add(btnNewButton);
	}
}
