package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.impl.MemberDaoImpl;
import model.Member;
import service.impl.MemberServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.ButtonGroup;

public class MemberUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_password;
	private JTextField textField_name;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	String mNo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MemberUI frame = new MemberUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MemberUI() {
		MemberServiceImpl msi=new MemberServiceImpl();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 368, 356);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 10, 328, 294);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("員編:");
		lblNewLabel.setBounds(44, 40, 46, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("密碼:");
		lblNewLabel_1.setBounds(44, 79, 46, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("姓名:");
		lblNewLabel_2.setBounds(44, 119, 46, 15);
		panel.add(lblNewLabel_2);
		
		JRadioButton Radio_male = new JRadioButton("男性");
		Radio_male.setSelected(true);
		buttonGroup.add(Radio_male);
		Radio_male.setBounds(40, 153, 63, 23);
		panel.add(Radio_male);
		
		
		JRadioButton Radio_Female = new JRadioButton("女性");
		buttonGroup.add(Radio_Female);
		Radio_Female.setBounds(105, 153, 57, 23);
		panel.add(Radio_Female);
		
		JLabel lblNewLabel_3 = new JLabel("部門:");
		lblNewLabel_3.setBounds(44, 198, 46, 15);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("職位:");
		lblNewLabel_4.setBounds(44, 239, 46, 15);
		panel.add(lblNewLabel_4);
		
		textField_password = new JTextField();
		textField_password.setBounds(78, 76, 96, 21);
		panel.add(textField_password);
		textField_password.setColumns(10);
		
		textField_name = new JTextField();
		textField_name.setBounds(78, 116, 96, 21);
		panel.add(textField_name);
		textField_name.setColumns(10);
		
		JComboBox comboBox_department = new JComboBox();
		comboBox_department.setBounds(78, 194, 73, 23);
		panel.add(comboBox_department);

		comboBox_department.addItem("管理部");
		comboBox_department.addItem("業務部");
		comboBox_department.addItem("工程部");
		
		JComboBox comboBox_jobTitle = new JComboBox();
		comboBox_jobTitle.setBounds(78, 235, 73, 23);
		panel.add(comboBox_jobTitle);
		
		comboBox_jobTitle.addItem("職員");
		
		if(LoginUI.member.getJobTitle().equals("admin")) 
		{
			comboBox_jobTitle.addItem("主管");
			comboBox_jobTitle.addItem("admin");
		}
		
		JLabel Label_memberNo = new JLabel("");
		Label_memberNo.setBounds(78, 36, 84, 23);
		panel.add(Label_memberNo);
		
		DateTimeFormatter dtFormatter=DateTimeFormatter.ofPattern("YYMM");
		LocalDate ld=LocalDate.now();
		String lds=ld.format(dtFormatter);
	
		if(LoginUI.updateState) {
			Member m=new MemberDaoImpl().selectById(LoginUI.updateId);
			mNo=m.getMemberNo();
			Label_memberNo.setText(mNo);
		}
		else {
			mNo=msi.countMemberNo(lds);
			Label_memberNo.setText(mNo);
		}

		
		/********按鈕區********/
		
		
		JButton Button_add = new JButton("送出");
		Button_add.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				String pw=textField_password.getText();
				String name=textField_name.getText();
				String sex="Male";
				
				if(Radio_Female.isSelected()) {sex="Female";}
				String dep=(String) comboBox_department.getSelectedItem();
				String jt=(String) comboBox_jobTitle.getSelectedItem();
				if(!pw.equals("") && !name.equals("")) 
				{
					Member mem=new Member(mNo,pw,name,sex,dep,jt);
					if(LoginUI.updateState) 
					{
						msi.updateMember(LoginUI.updateId, mem);
						JOptionPane.showMessageDialog(Button_add,"修改成功。");
						textField_password.setText("");
						textField_name.setText("");
						mNo=msi.countMemberNo(lds);
						LoginUI.updateState=false;
						dispose();
					}
					else {
						msi.addMember(mem);
						JOptionPane.showMessageDialog(Button_add,"新增成功。");
						textField_password.setText("");
						textField_name.setText("");
						mNo=msi.countMemberNo(lds);
						Label_memberNo.setText(mNo);
					}
				}
				else 
					{
					JOptionPane.showMessageDialog(Button_add,"錯誤，密碼跟姓名為必填欄位。");
					Label_memberNo.setText(mNo);
					}
				
			}
		});
		Button_add.setBounds(231, 220, 87, 23);
		panel.add(Button_add);
		
		JButton Button_cancel = new JButton("返回");
		Button_cancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuUI menuUi=new MenuUI();
				menuUi.setVisible(true);
				dispose();
			}
		});
		Button_cancel.setBounds(231, 261, 87, 23);
		panel.add(Button_cancel);
		
		
		
	}
}
