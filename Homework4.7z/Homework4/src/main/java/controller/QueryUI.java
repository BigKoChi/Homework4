package controller;

import java.awt.EventQueue;
//import java.awt.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import model.LeaveRecord;
import model.Member;
import model.WorkRecord;
import service.impl.LeaveRecordServiceImpl;
import service.impl.MemberServiceImpl;
import service.impl.WorkRecordServiceImpl;
import util.Tool;

import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;

import javax.swing.JSpinner;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SpinnerNumberModel;


public class QueryUI extends JFrame {

	private static final long serialVersionUID = 1L;
	//private static final java.util.List<WorkRecord> WorkRecord = null;
	private JPanel contentPane;
	private JTable table;
	DefaultTableModel tableModel;
	int tableState=0;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QueryUI frame = new QueryUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public QueryUI() {
		
		MemberServiceImpl msi=new MemberServiceImpl();
		WorkRecordServiceImpl wsi=new WorkRecordServiceImpl();
		LeaveRecordServiceImpl lsi=new LeaveRecordServiceImpl();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 501, 433);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 465, 205);
		contentPane.add(scrollPane);
		
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 225, 465, 74);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("欲查詢姓名:");
		lblNewLabel.setBounds(10, 10, 88, 15);
		panel.add(lblNewLabel);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(108, 6, 74, 23);
		panel.add(comboBox);
		
		if(LoginUI.member.getJobTitle().equals("admin")) {
			List<Member> lm=msi.findAllMember();
			List<String> memberName=new ArrayList<>();
			comboBox.addItem("ALL");
			for(Member m:lm) 
			{
				memberName.add(m.getName());
			}
		
			for(String s:memberName) 
			{
				
				comboBox.addItem(s);
			}
		}
		else if(LoginUI.member.getJobTitle().equals("主管"))
		{
			List<Member> lm=msi.findAllMember();
			List<String> memberName=new ArrayList<>();
			comboBox.addItem("ALL");
			for(Member m:lm) 
			{
				if(m.getDepartment().equals(LoginUI.member.getDepartment())) 
				{
					memberName.add(m.getName());
				}
			}
			for(String s:memberName) 
			{
				comboBox.addItem(s);
			}
		}
		else if(LoginUI.member.getJobTitle().equals("職員")) 
		{
			Member lm=msi.findByMemberNo(LoginUI.member.getMemberNo());
			comboBox.addItem(lm.getName());
		}
	
		
		
		
		JButton Button_back = new JButton("返回");
		Button_back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MenuUI menuUi=new MenuUI();
				menuUi.setVisible(true);
				dispose();
			}
		});
		Button_back.setBounds(368, 39, 87, 23);
		panel.add(Button_back);
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 309, 465, 75);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("欲更動之ID號:");
		lblNewLabel_1.setBounds(10, 10, 91, 15);
		panel_1.add(lblNewLabel_1);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
		spinner.setBounds(95, 7, 55, 22);
		panel_1.add(spinner);
		
		/***********按鈕區************/
		
		Tool tool=new Tool();
		
		JButton Button_member = new JButton("個人資料");
		Button_member.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				List<Member> cbBox_list=msi.findAllMember();
				String cbBox_name=(String)comboBox.getSelectedItem();
				String cbBox_memberNo="";
				for(Member m:cbBox_list) 
				{
					if(m.getName().equals(cbBox_name)) 
					{
						cbBox_memberNo=(m.getMemberNo());
					}
				}
				
				if(LoginUI.member.getJobTitle().equals("admin") && cbBox_name.equals("ALL"))
				{
					table = new JTable(tool.getTM_Member_All());
				}
				else if(LoginUI.member.getJobTitle().equals("主管") && cbBox_name.equals("ALL"))
				{
					table = new JTable(tool.getTM_Member_Dep(LoginUI.member.getDepartment()));
				}
				else 
				{
					table = new JTable(tool.getTM_Member_mem(cbBox_memberNo));
				}
				tableState=1;
				scrollPane.setViewportView(table);

			}
		});
		Button_member.setBounds(10, 39, 87, 23);
		panel.add(Button_member);
		
		JButton Button_workRecord = new JButton("刷卡紀錄");
		Button_workRecord.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				List<Member> cbBox_list=msi.findAllMember();
				String cbBox_name=(String)comboBox.getSelectedItem();
				String cbBox_memberNo="";
				for(Member m:cbBox_list) 
				{
					if(m.getName().equals(cbBox_name)) 
					{
						cbBox_memberNo=(m.getMemberNo());
					}
				}
				if(LoginUI.member.getJobTitle().equals("admin")&& cbBox_name.equals("ALL")) 
				{
					table = new JTable(tool.getTM_WorkRecord_All());
				}
				else if(LoginUI.member.getJobTitle().equals("主管")&& cbBox_name.equals("ALL")) 
				{
					table = new JTable(tool.getTM_WorkRecord_Dep(LoginUI.member.getDepartment()));
				}
				else 
				{
					table = new JTable(tool.getTM_WorkRecord_mem(cbBox_memberNo));
				}
				tableState=2;
				scrollPane.setViewportView(table);
				
			}
		});
		Button_workRecord.setBounds(107, 39, 87, 23);
		panel.add(Button_workRecord);
		
		JButton Button_leaveRecord = new JButton("請假紀錄");
		Button_leaveRecord.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				List<Member> cbBox_list=msi.findAllMember();
				String cbBox_name=(String)comboBox.getSelectedItem();
				String cbBox_memberNo="";
				for(Member m:cbBox_list) 
				{
					if(m.getName().equals(cbBox_name)) 
					{
						cbBox_memberNo=(m.getMemberNo());
					}
				}
				if(LoginUI.member.getJobTitle().equals("admin")&& cbBox_name.equals("ALL")) 
				{
					table = new JTable(tool.getTM_LeaveRecord_All());
				}
				else if(LoginUI.member.getJobTitle().equals("主管")&& cbBox_name.equals("ALL")) 
				{
					table = new JTable(tool.getTM_LeaveRecord_Dep(LoginUI.member.getDepartment()));
				}
				else 
				{
					table = new JTable(tool.getTM_LeaveRecord_mem(cbBox_memberNo));
				}
				tableState=3;
				scrollPane.setViewportView(table);
			}
		});
		Button_leaveRecord.setBounds(204, 39, 87, 23);
		panel.add(Button_leaveRecord);
		
		JButton Button_update = new JButton("修改");
		Button_update.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginUI.updateId=(int)spinner.getValue();
				LoginUI.updateState=true;
				if(!LoginUI.member.getJobTitle().equals("職員")) {
					
				switch(tableState) 
				{
				case 1:
					
					new MemberUI().setVisible(true);
					break;
				case 2:
					JOptionPane.showMessageDialog(Button_update, "刷卡資料為當下時間紀錄，只做查詢跟刪除");
					break;
				case 3:
					new LeaveRecordUI().setVisible(true);
					break;
				default:
					JOptionPane.showMessageDialog(Button_update, "請先查詢資料");
		
				}
				}
				else {
					JOptionPane.showMessageDialog(Button_update, "權限不足，只有主管級權限以上才可修改跟刪除。");
				}
			}
		});
		Button_update.setBounds(10, 42, 87, 23);
		panel_1.add(Button_update);
		
		JButton Button_delete = new JButton("刪除");
		Button_delete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int id=(int)spinner.getValue();
				if(!LoginUI.member.getJobTitle().equals("職員")) {
				switch(tableState) 
				{
				case 1:
					msi.deleteMember(id);
					JOptionPane.showMessageDialog(Button_delete, "刪除完成，請重新查詢");
					break;
				case 2:
					wsi.deleteWorkRecord(id);
					JOptionPane.showMessageDialog(Button_delete, "刪除完成，請重新查詢");
					break;
				case 3:
					lsi.deleteLeaveRecord(id);
					JOptionPane.showMessageDialog(Button_delete, "刪除完成，請重新查詢");
					break;
				default:
					JOptionPane.showMessageDialog(Button_delete, "請先查詢資料");
				}
				
				}
				else {
					JOptionPane.showMessageDialog(Button_update, "權限不足，只有主管級權限以上才可修改跟刪除。");
				}
			}
		});
		Button_delete.setBounds(105, 42, 87, 23);
		panel_1.add(Button_delete);

	}
}
