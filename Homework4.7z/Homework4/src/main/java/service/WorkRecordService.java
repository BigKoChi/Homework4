package service;

import java.util.List;


import model.WorkRecord;

public interface WorkRecordService {
	void addWorkRecord(WorkRecord workRecord); 
	List<WorkRecord> findAllWorkRecord();
	List<WorkRecord> findByMemberNo(String memberNo);
	boolean updateWorkRecord(int id,WorkRecord workRecord);
	boolean deleteWorkRecord(int id);
}
