package service;

import java.util.List;

import model.Member;

public interface MemberService {

	boolean addMember(Member member); 
	List<Member> findAllMember();
	Member findByMemberNo(String memberNo);
	String countMemberNo(String yymm);
	boolean updateMember(int id,Member member);
	boolean deleteMember(int id);
}
