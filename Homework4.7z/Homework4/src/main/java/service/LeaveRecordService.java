package service;

import java.util.List;

import model.LeaveRecord;



public interface LeaveRecordService {
	void addLeaveRecord(LeaveRecord leaveRecord); 
	List<LeaveRecord> findAllLeaveRecord();
	List<LeaveRecord> findByMemberNo(String memberNo);
	boolean updateLeaveRecord(int id,LeaveRecord leaveRecord);
	boolean deleteLeaveRecord(int id);
}
