package service.impl;

import java.util.List;

import dao.impl.WorkRecordDaoImpl;
import model.WorkRecord;
import service.WorkRecordService;

public class WorkRecordServiceImpl implements WorkRecordService{

	WorkRecordDaoImpl wdi=new WorkRecordDaoImpl();
	@Override
	public void addWorkRecord(WorkRecord workRecord) {
	
			wdi.add(workRecord);
	}

	@Override
	public List<WorkRecord> findAllWorkRecord() {
		
		return wdi.selectAll();
	}

	@Override
	public List<WorkRecord> findByMemberNo(String memberNo) {
		
		return wdi.selectByMemberNo(memberNo);
	}

	@Override
	public boolean updateWorkRecord(int id, WorkRecord workRecord) {
		boolean boo=false;
		if(wdi.selectById(id) !=null) 
		{
			wdi.update(id,workRecord);
			boo=true;
		}
		return boo;
	}

	@Override
	public boolean deleteWorkRecord(int id) {
		boolean boo=false;
		if(wdi.selectById(id)!=null) 
		{
			wdi.delete(id);;
			boo=true;
		}
		return boo;
	}

}
