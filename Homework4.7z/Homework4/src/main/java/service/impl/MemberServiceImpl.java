package service.impl;

import java.util.List;

import dao.impl.MemberDaoImpl;
import model.Member;
import service.MemberService;

public class MemberServiceImpl implements MemberService{

	MemberDaoImpl mdi=new MemberDaoImpl();
	@Override
	public boolean addMember(Member member) {
		boolean boo=false;
		if(mdi.selectByMemberNo(member.getMemberNo()) ==null) 
		{
			mdi.add(member);
			boo=true;
		}
		return boo;
	}

	@Override
	public List<Member> findAllMember() {
		
		return mdi.selectAll();
	}

	@Override
	public Member findByMemberNo(String memberNo) {
		
		return mdi.selectByMemberNo(memberNo);
	}

	@Override
	public boolean updateMember(int id,Member member) {
		boolean boo=false;
		if(mdi.selectByMemberNo(member.getMemberNo()) !=null) 
		{
			mdi.update(id,member);
			boo=true;
		}
		return boo;
	}

	@Override
	public boolean deleteMember(int id) {
		boolean boo=false;
		if(mdi.selectById(id)!=null) 
		{
			mdi.delete(id);;
			boo=true;
		}
		return boo;
	}

	@Override
	public String countMemberNo(String yymm) {
		int countInt=mdi.count(yymm)+1;
		String countString="A"+yymm+String.format("%03d", countInt);
		return countString;
	}

}
