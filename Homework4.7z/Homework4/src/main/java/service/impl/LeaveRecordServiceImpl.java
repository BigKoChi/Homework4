package service.impl;

import java.util.List;

import dao.impl.LeaveRecordDaoImpl;
import model.LeaveRecord;
import service.LeaveRecordService;

public class LeaveRecordServiceImpl implements LeaveRecordService {

	LeaveRecordDaoImpl ldi=new LeaveRecordDaoImpl();
	@Override
	public void addLeaveRecord(LeaveRecord leaveRecord) {
		
		ldi.add(leaveRecord);
	}

	@Override
	public List<LeaveRecord> findAllLeaveRecord() {
		
		return ldi.selectAll();
	}

	@Override
	public List<LeaveRecord> findByMemberNo(String memberNo) {
		
		return ldi.selectByMemberNo(memberNo);
	}

	@Override
	public boolean updateLeaveRecord(int id, LeaveRecord leaveRecord) {
		boolean boo=false;
		if(ldi.selectById(id)!=null) 
		{
			ldi.update(id,leaveRecord);
			boo=true;
		}
		return boo;
	}

	@Override
	public boolean deleteLeaveRecord(int id) {
		boolean boo=false;
		if(ldi.selectById(id)!=null) 
		{
			ldi.delete(id);;
			boo=true;
		}
		return boo;
	}

}
